import React from 'react';

const DisplayItem= ({item}) =>{
    return(
        <div>
            <h1>{item}</h1>
        </div>
    )
}

export default DisplayItem;